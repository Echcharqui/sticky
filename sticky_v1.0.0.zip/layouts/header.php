<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="#" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <title> <?= generateHeadTitle($pwd) ?></title>
    <script type="module" crossorigin src="/assets/main-D_J3YjDD.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/main-CObkJrV3.css">
</head>

<body>